package Model;

public class Motor extends Kendaraan {
    private int cc;

    public Motor(String nama, double harga, int cc) {
        super(nama, "Motor", harga);
        this.cc = cc;
    }

    public int getCc() {
        return cc;
    }

    public void setCc(int cc) {
        this.cc = cc;
    }

    @Override
    public String getInfo() {
        return super.getInfo() + " | CC: " + cc;
    }
}
