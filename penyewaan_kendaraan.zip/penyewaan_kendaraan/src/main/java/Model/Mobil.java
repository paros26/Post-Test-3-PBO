package Model;

public class Mobil extends Kendaraan {
    private int kapasitasPenumpang;

    public Mobil(String nama, double harga, int kapasitasPenumpang) {
        super(nama, "Mobil", harga);
        this.kapasitasPenumpang = kapasitasPenumpang;
    }

    public int getKapasitasPenumpang() {
        return kapasitasPenumpang;
    }

    public void setKapasitasPenumpang(int kapasitasPenumpang) {
        this.kapasitasPenumpang = kapasitasPenumpang;
    }

    @Override
    public String getInfo() {
        return super.getInfo() + " | Kapasitas: " + kapasitasPenumpang + " orang";
    }
}
